package com.timecal.calendar;
import android.app.*;
import android.content.*;
import android.os.Build;
import android.provider.Settings;
import android.net.Uri;
import java.time.*;
import java.util.*;

public final class Reminders extends BroadcastReceiver {
    static final String CHANNEL="timecal_reminders_v2", ACTION="com.timecal.calendar.REMIND";
    static final long DAY=86400000L;
    static final String PREF="timecal_alarm_history";
    static void channel(Context c){NotificationManager n=c.getSystemService(NotificationManager.class);NotificationChannel ch=new NotificationChannel(CHANNEL,"日历任务、生日与节日提醒",NotificationManager.IMPORTANCE_HIGH);ch.enableVibration(true);ch.setVibrationPattern(new long[]{0,350,200,350});ch.setSound(Settings.System.DEFAULT_NOTIFICATION_URI,new android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_NOTIFICATION).build());n.createNotificationChannel(ch);}
    static boolean exact(Context c){return Build.VERSION.SDK_INT<31||c.getSystemService(AlarmManager.class).canScheduleExactAlarms();}
    static boolean allowed(Context c){NotificationManager n=c.getSystemService(NotificationManager.class);return n.areNotificationsEnabled()&&(n.getNotificationChannel(CHANNEL)==null||n.getNotificationChannel(CHANNEL).getImportance()!=NotificationManager.IMPORTANCE_NONE);}
    static PendingIntent alarm(Context c){return PendingIntent.getBroadcast(c,1,new Intent(c,Reminders.class).setAction(ACTION),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
    static final class Notice {
        final Store.Entry entry; final int lead;
        Notice(Store.Entry e,int l){entry=e;lead=l;}
        long when(){return LocalDate.parse(entry.date).atTime(LocalTime.parse(entry.time)).minusMinutes(lead).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();}
        String key(){return entry.id+"/"+entry.date+"/"+entry.time+"/"+lead;}
    }
    static List<Notice> candidates(Store s,LocalDate today){
        HolidayUpdates.init(s.ctx);
        List<Store.Entry> entries=s.all(),result=new ArrayList<>();
        Store.Entry cn=HolidayReminders.config(s,"CN"),ar=HolidayReminders.config(s,"AR"),recurring=HolidayReminders.config(s,"RECURRING");
        for(int i=-2;i<=9;i++){LocalDate day=today.plusDays(i);for(Store.Entry e:s.day(day,entries))if(ReminderPolicy.enabled(e,recurring)&&!e.done){e.leads=ReminderPolicy.mask(e,recurring);result.add(e);}HolidayReminders.append(result,day,cn,"CN");HolidayReminders.append(result,day,ar,"AR");}
        List<Notice> notices=new ArrayList<>();for(Store.Entry e:result)for(int i=0;i<LeadTimes.MINUTES.length;i++)if((e.leads&(1<<i))!=0)notices.add(new Notice(e,LeadTimes.MINUTES[i]));return notices;
    }
    static synchronized void schedule(Context c){
        Store s=new Store(c);AlarmManager am=c.getSystemService(AlarmManager.class);PendingIntent pi=alarm(c);long now=System.currentTimeMillis();LocalDate today=LocalDate.now();long next=today.plusDays(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli();SharedPreferences h=c.getSharedPreferences(PREF,0);boolean enabled=HolidayReminders.enabled(HolidayReminders.config(s,"CN"))||HolidayReminders.enabled(HolidayReminders.config(s,"AR"));
        Store.Entry recurring=HolidayReminders.config(s,"RECURRING");
        for(Store.Entry e:s.all())if(e.parent.isEmpty()&&!e.deleted&&!HolidayReminders.isConfig(e)&&ReminderPolicy.enabled(e,recurring)&&(!e.repeat.equals("none")||!e.done)){enabled=true;break;}
        if(!enabled){am.cancel(pi);return;}
        for(Notice notice:candidates(s,today)){long t=notice.when();if(h.contains(notice.key()))continue;if(t>now)next=Math.min(next,t);else if(t>=now-DAY&&allowed(c))next=Math.min(next,now+1000);}
        try{if(exact(c))am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,next,pi);else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,next,pi);}catch(SecurityException e){am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,next,pi);}
    }
    @Override public void onReceive(Context c,Intent i){channel(c);if(ACTION.equals(i.getAction())&&allowed(c)){long now=System.currentTimeMillis();SharedPreferences h=c.getSharedPreferences(PREF,0);NotificationManager n=c.getSystemService(NotificationManager.class);for(Notice notice:candidates(new Store(c),LocalDate.now())){Store.Entry e=notice.entry;long t=notice.when();String k=notice.key();if(t>now||t<now-DAY||h.contains(k))continue;Intent open=new Intent(c,MainActivity.class).putExtra("open_date",e.date).setData(Uri.parse("timecal://date/"+e.date)).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);PendingIntent p=PendingIntent.getActivity(c,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);Notification notification=new Notification.Builder(c,CHANNEL).setSmallIcon(R.drawable.ic_calendar).setContentTitle(e.title).setContentText(e.date+" "+e.time+" · "+LeadTimes.label(notice.lead)).setStyle(new Notification.BigTextStyle().bigText(e.date+" "+e.time+" · "+e.kind+" · "+LeadTimes.label(notice.lead))).setContentIntent(p).setAutoCancel(true).setLocalOnly(true).setCategory(Notification.CATEGORY_REMINDER).build();try{n.notify(k,1,notification);h.edit().putLong(k,now).apply();}catch(SecurityException ignored){}}}
        // Trim only old delivery receipts; past occurrences are never rescheduled outside the catch-up window.
        SharedPreferences h=c.getSharedPreferences(PREF,0);SharedPreferences.Editor ed=h.edit();for(Map.Entry<String,?> e:h.getAll().entrySet())if(e.getValue() instanceof Long&&(Long)e.getValue()<System.currentTimeMillis()-30*DAY)ed.remove(e.getKey());ed.apply();schedule(c);
    }
}
