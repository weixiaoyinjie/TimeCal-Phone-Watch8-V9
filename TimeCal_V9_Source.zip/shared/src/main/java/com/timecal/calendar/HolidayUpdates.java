package com.timecal.calendar;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import org.json.*;
import java.net.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.time.*;
import java.util.*;
import java.util.concurrent.*;
import java.text.Normalizer;

/** Public holiday data only; never sends task or personal information. */
final class HolidayUpdates {
    static final long TTL=24*60*60*1000L;
    static final ExecutorService IO=Executors.newSingleThreadExecutor();
    static final Map<String,Map<LocalDate,String>> CACHE=new ConcurrentHashMap<>();
    static final Set<String> running=ConcurrentHashMap.newKeySet();
    static SharedPreferences prefs;
    static synchronized void init(Context c){if(prefs!=null)return;prefs=c.getApplicationContext().getSharedPreferences("timecal_holidays_v3",0);for(String key:prefs.getAll().keySet())if(key.startsWith("data_")){try{CACHE.put(key.substring(5),decode(prefs.getString(key,"")));}catch(Exception ignored){}}}
    static Map<LocalDate,String> decode(String data)throws JSONException{JSONObject j=new JSONObject(data);Map<LocalDate,String> m=new HashMap<>();Iterator<String> keys=j.keys();while(keys.hasNext()){String k=keys.next();m.put(LocalDate.parse(k),j.getString(k));}return Collections.unmodifiableMap(m);}
    static String cached(String country,LocalDate d){Map<LocalDate,String> m=CACHE.get(country+d.getYear());return m==null?null:m.getOrDefault(d,"");}
    static String status(int year){StringBuilder b=new StringBuilder();for(String c:new String[]{"CN","AR"}){String key=c+year;long t=prefs.getLong("ok_"+key,0);b.append(c.equals("CN")?"中国：":"阿根廷：").append(t==0?"离线规则": "缓存更新 "+Instant.ofEpochMilli(t).atZone(ZoneId.systemDefault()).toLocalDate());String error=prefs.getString("error_"+key,"");if(!error.isEmpty())b.append("（最近更新未成功）");b.append('\n');}return b.toString();}
    static void refresh(int year,boolean force,Runnable done){if(prefs==null||year<1901||year>2099)return;for(String c:new String[]{"CN","AR"}){String k=c+year;long now=System.currentTimeMillis();if(!force&&now-prefs.getLong("try_"+k,0)<TTL)continue;if(!running.add(k))continue;prefs.edit().putLong("try_"+k,now).apply();IO.execute(()->{try{Map<LocalDate,String> m=c.equals("CN")?china(year):argentina(year);JSONObject j=new JSONObject();for(Map.Entry<LocalDate,String> e:m.entrySet())j.put(e.getKey().toString(),e.getValue());prefs.edit().putString("data_"+k,j.toString()).putLong("ok_"+k,System.currentTimeMillis()).remove("error_"+k).apply();CACHE.put(k,Collections.unmodifiableMap(m));}catch(Exception ex){prefs.edit().putString("error_"+k,"failed").apply();android.util.Log.w("TimeCal","Holiday refresh failed: "+k,ex);}finally{running.remove(k);new Handler(Looper.getMainLooper()).post(done);}});}}
    static String fetch(String url)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(7000);c.setReadTimeout(7000);c.setRequestProperty("Accept","application/json");try{if(c.getResponseCode()!=200)throw new IOException("HTTP "+c.getResponseCode());try(InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1){if(out.size()+n>512000)throw new IOException("Response too large");out.write(b,0,n);}return new String(out.toByteArray(),StandardCharsets.UTF_8);}}finally{c.disconnect();}}
    static Map<LocalDate,String> china(int y)throws Exception{JSONObject j=new JSONObject(fetch("https://timor.tech/api/holiday/year/"+y+"/"));if(j.getInt("code")!=0)throw new IOException("Unavailable year");JSONObject h=j.getJSONObject("holiday");Map<LocalDate,String> m=new HashMap<>();Iterator<String> it=h.keys();int count=0;while(it.hasNext()){String k=it.next();JSONObject v=h.getJSONObject(k);LocalDate d=LocalDate.parse(y+"-"+k);if(d.getYear()!=y||!v.getString("date").equals(d.toString()))throw new IOException("Invalid date");if(v.getBoolean("holiday")){String name=v.getString("name").trim();if(name.isEmpty())throw new IOException("Empty name");if(name.matches("初[一二三四五六七八九十]"))name="春节假期";m.put(d,name);count++;}}if(count<10||!m.containsKey(LocalDate.of(y,1,1))||!m.containsKey(LocalDate.of(y,10,1)))throw new IOException("Incomplete year");return m;}
    static Map<LocalDate,String> argentina(int y)throws Exception{JSONArray a=new JSONArray(fetch("https://api.argentinadatos.com/v1/feriados/"+y));Map<LocalDate,String> m=new HashMap<>();for(int i=0;i<a.length();i++){JSONObject j=a.getJSONObject(i);LocalDate d=LocalDate.parse(j.getString("fecha"));String n=j.getString("nombre").trim();if(d.getYear()!=y||n.isEmpty())throw new IOException("Invalid date/name");String name=translate(n,j.optString("tipo"));m.merge(d,name,(x,z)->x.equals(z)?x:x+" · "+z);}if(m.size()<10||!m.containsKey(LocalDate.of(y,1,1))||!m.containsKey(LocalDate.of(y,12,25)))throw new IOException("Incomplete year");return m;}
    static String translate(String n,String type){String s=Normalizer.normalize(n,Normalizer.Form.NFD).replaceAll("\\p{M}","").toLowerCase(Locale.ROOT);if(s.contains("ano nuevo"))return "元旦";if(s.contains("carnaval"))return "狂欢节";if(s.contains("memoria")&&s.contains("justicia"))return "真相与正义纪念日";if(s.contains("malvinas"))return "马岛纪念日";if(s.contains("viernes santo"))return "耶稣受难日";if(s.contains("jueves santo"))return "圣周四·非工作日";if(s.contains("trabajador")||s.contains("trabajo"))return "劳动节";if(s.contains("revolucion de mayo"))return "五月革命纪念日";if(s.contains("guemes"))return "格梅斯纪念日";if(s.contains("belgrano")||s.contains("bandera"))return "国旗日";if(s.contains("independencia"))return "独立日";if(s.contains("san martin"))return "圣马丁纪念日";if(s.contains("diversidad cultural"))return "文化多样性日";if(s.contains("soberania nacional"))return "国家主权日";if(s.contains("inmaculada"))return "圣母无染原罪节";if(s.contains("navidad"))return "圣诞节";if(type.equals("puente")||s.contains("turistic"))return "旅游非工作日";return n;}
}
