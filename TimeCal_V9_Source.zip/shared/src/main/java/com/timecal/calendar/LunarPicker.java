package com.timecal.calendar;

import android.app.AlertDialog;
import android.widget.*;
import android.view.View;
import android.icu.util.Calendar;
import java.time.*;
import java.util.*;
import java.util.function.Consumer;

final class LunarPicker {
    static class Month {
        final LocalDate first; final int days; final String name;
        Month(LocalDate first, Calendar c){this.first=first;days=c.getActualMaximum(Calendar.DAY_OF_MONTH);name=(c.get(Calendar.IS_LEAP_MONTH)==1?"闰":"")+Holidays.MONTH[c.get(Calendar.MONTH)];}
    }
    static LocalDate newYear(int y){LocalDate d=LocalDate.of(y,1,1);for(int i=0;i<80;i++,d=d.plusDays(1)){Calendar c=Holidays.lunar(d);if(c.get(Calendar.MONTH)==0&&c.get(Calendar.DAY_OF_MONTH)==1&&c.get(Calendar.IS_LEAP_MONTH)==0)return d;}throw new IllegalStateException("Cannot locate lunar year "+y);}
    static List<Month> months(int y){List<Month> m=new ArrayList<>();LocalDate d=newYear(y),end=newYear(y+1);while(d.isBefore(end)){Month x=new Month(d,Holidays.lunar(d));m.add(x);d=d.plusDays(x.days);}if(!d.equals(end))throw new IllegalStateException("Lunar month boundary mismatch");return m;}
    static void show(MainActivity a,LocalDate initial,Consumer<LocalDate> selected){
        int y=initial.getYear();if(initial.isBefore(newYear(y)))y--;
        LinearLayout panel=a.column();panel.setPadding(a.dp(20),a.dp(4),a.dp(20),a.dp(8));
        panel.addView(a.label("农历年份",15,MainActivity.GREEN));NumberPicker year=new NumberPicker(a);year.setMinValue(1900);year.setMaxValue(2099);year.setWrapSelectorWheel(false);year.setValue(Math.max(1900,Math.min(2099,y)));panel.addView(year,new LinearLayout.LayoutParams(-1,a.dp(105)));
        panel.addView(a.label("农历月份（自动列出闰月）",15,MainActivity.GREEN));Spinner month=new Spinner(a);panel.addView(month);
        panel.addView(a.label("农历日期",15,MainActivity.GREEN));Spinner day=new Spinner(a);panel.addView(day);
        TextView preview=a.label("",16,MainActivity.WHITE);panel.addView(preview);ScrollView scroll=new ScrollView(a);scroll.addView(panel);
        final List<Month> list=new ArrayList<>();final int[] preferred={Holidays.lunar(initial).get(Calendar.DAY_OF_MONTH)};final boolean[] busy={false};
        Runnable updatePreview=()->{int i=month.getSelectedItemPosition(),j=day.getSelectedItemPosition();if(i>=0&&i<list.size()&&j>=0&&j<list.get(i).days){LocalDate d=list.get(i).first.plusDays(j);preview.setText("公历："+d+"\n农历："+Holidays.lunarText(d,true));}};
        Runnable setDays=()->{int i=month.getSelectedItemPosition();if(i<0||i>=list.size())return;int len=list.get(i).days;String[] names=Arrays.copyOfRange(Holidays.DAY,1,len+1);day.setAdapter(new ArrayAdapter<>(a,android.R.layout.simple_spinner_dropdown_item,names));day.setSelection(Math.min(len,Math.max(1,preferred[0]))-1);updatePreview.run();};
        java.util.function.IntConsumer setMonths=(index)->{busy[0]=true;list.clear();list.addAll(months(year.getValue()));String[] names=new String[list.size()];for(int i=0;i<names.length;i++)names[i]=list.get(i).name;month.setAdapter(new ArrayAdapter<>(a,android.R.layout.simple_spinner_dropdown_item,names));month.setSelection(Math.max(0,Math.min(index,names.length-1)));busy[0]=false;setDays.run();};
        List<Month> initialMonths=months(year.getValue());int idx=0;for(int i=0;i<initialMonths.size();i++){Month m=initialMonths.get(i);if(!initial.isBefore(m.first)&&initial.isBefore(m.first.plusDays(m.days))){idx=i;break;}}setMonths.accept(idx);
        year.setOnValueChangedListener((p,old,v)->setMonths.accept(month.getSelectedItemPosition()));
        month.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){}public void onItemSelected(android.widget.AdapterView<?> p,View v,int i,long id){if(!busy[0])setDays.run();}});
        day.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){}public void onItemSelected(android.widget.AdapterView<?> p,View v,int i,long id){preferred[0]=i+1;updatePreview.run();}});
        AlertDialog dialog=new AlertDialog.Builder(a).setTitle("选择农历日期").setView(scroll).setNegativeButton("取消",null).setPositiveButton("确定",null).create();dialog.setOnShowListener(v->dialog.getButton(-1).setOnClickListener(b->{int i=month.getSelectedItemPosition(),j=day.getSelectedItemPosition();if(i<0||i>=list.size()||j<0||j>=list.get(i).days)return;LocalDate d=list.get(i).first.plusDays(j);if(d.getYear()<1901||d.getYear()>2099){Toast.makeText(a,"请选择公历1901–2099年范围内的日期",Toast.LENGTH_LONG).show();return;}selected.accept(d);dialog.dismiss();}));dialog.show();
    }
}
