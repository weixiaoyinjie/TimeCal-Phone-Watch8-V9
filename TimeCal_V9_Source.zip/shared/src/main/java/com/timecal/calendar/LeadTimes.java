package com.timecal.calendar;
import java.util.*;
final class LeadTimes {
    static final int[] MINUTES={0,5,10,15,30,60,120,1440,4320,10080};
    static final int ALL=(1<<MINUTES.length)-1;
    static int single(int minutes){for(int i=0;i<MINUTES.length;i++)if(MINUTES[i]==minutes)return 1<<i;return 1;}
    static int normalize(int mask){int m=mask&ALL;return m==0?1:m;}
    static int first(int mask){return MINUTES[Integer.numberOfTrailingZeros(normalize(mask))];}
    static String label(int minutes){if(minutes==0)return "准时提醒";if(minutes%1440==0)return "提前"+(minutes/1440)+"天";if(minutes%60==0)return "提前"+(minutes/60)+"小时";return "提前"+minutes+"分钟";}
    static String summary(int mask){List<String> labels=new ArrayList<>();for(int i=0;i<MINUTES.length;i++)if((mask&(1<<i))!=0)labels.add(label(MINUTES[i]));return String.join("、",labels);}
}
